class PanDDARunHTML:
    # Produces a HTML from Statistics
    def __init__():
