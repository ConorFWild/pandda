

class Section(object):
    pass

class Header(Section):
    pass

class Content(Section):
    pass

class Footer(Section):
    pass

