from collections import OrderedDict

class GetReference:
    def __init__(self):
        pass

    def __call__(self, *args, **kwargs):
        pass

    def repr(self):
        repr = OrderedDict()
        return repr