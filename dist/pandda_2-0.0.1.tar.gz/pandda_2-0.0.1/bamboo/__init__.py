# Contains all non-specialist code for the analysis of protein and ligand structures
# Does NOT require cctbx

import os, sys

from bamboo.common.errors import *

