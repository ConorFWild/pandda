
import jinja2

GIANT_HTML_ENV = jinja2.Environment(loader=jinja2.PackageLoader('giant', 'templates'))


